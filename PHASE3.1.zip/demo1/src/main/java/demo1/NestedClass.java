package demo1;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.shadow.com.univocity.parsers.annotations.Nested;


public class NestedClass {

	@BeforeAll
	static void beforeAll()
	{
		System.out.println("before all test method");
	}
	
	@BeforeEach
	void beforeEach()
	{
		System.out.println("before each test method");
	}
	
	@AfterEach
	void afterEach()
	{
		System.out.println("after each test method");
	}
	
	@AfterAll
	static void afterAll() {
		System.out.println("after all test methods");
	}
	

	
	@DisplayName("Tests for method A")
	class A {
		
		@BeforeEach
		void beforeEach()
		{
			System.out.println("before each test method of A");
			
		}
		
		@AfterEach
		void afterEach() {
			System.out.println("after each test method of A");
		}
		
		@Test
		@DisplayName("example test for method A")
		void sampleTestForMethodA()
		{
			System.out.println("Example test for method A");
		}
		
		
		@DisplayName("when X is true")
		class WhenX
		{
			@BeforeEach
			void beforeEach()
			{
				System.out.println("before each test method of WhenX");
				
			}
			
			@AfterEach
			void afterEach() {
				System.out.println("after each test method of WhenX");
			}
			
			@Test
			@DisplayName("example test for method WhenX")
			void sampleTestForMethodWhenX()
			{
				System.out.println("Example test for method WhenX");
			}
			
		}
	}
	
}	
